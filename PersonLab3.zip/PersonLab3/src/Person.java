public class Person {
    public String fName="";
    public String lName="";
    public int age=0;
    public static boolean human = true;

    public Person(String arg1, String arg2, int arg3)
    {
        fName=arg1;
        lName=arg2;
        age=arg3;
    }

    public Person(String arg1and2, int arg3)
    {
        //arg1and2 is arg1 and arg2 combined
        fName=arg1and2.substring(0, arg1and2.indexOf(' '));
        lName=arg1and2.substring(arg1and2.indexOf(' ')+1);
        age=arg3;
    }
}
