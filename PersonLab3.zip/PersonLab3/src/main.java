public class main {
    public static void main(String[] args) {
        Person[] people = new Person[]{new Person("Joe","Shmoe",95),new Person("Eddie","Davis IV",-10),new Person("Bob Johnson",46),new Person("John","Smith III", 106)};
        for(int i=0; i<people.length; i++)
        {
            System.out.println("First Name: "+ people[i].fName+", Last Name: "+ people[i].lName+", Age: "+ people[i].age);
        }
    }
}
