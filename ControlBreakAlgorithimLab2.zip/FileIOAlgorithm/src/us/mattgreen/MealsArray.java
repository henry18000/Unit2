package us.mattgreen;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * Created by mgreen14 on 12/29/17.
 */
public class MealsArray {
    private Meals[] meals = new Meals[100];
    private int i = 0;
    private int calories;

    public String getTotal(MealType meal1) {
        int calories = 0;
        int total = 0;
        int min = 100000;
        int max = 0;
        int mean = 0;
        int median = 0;
        ArrayList<Meals> display = new ArrayList<Meals>();

        for (int i = 0; i < 100; i++) {
            if (meals[i] == null) {
                break;
            } else if (meals[i].getMealType() == meal1) {
                total++;
                display.add(meals[i]);
                if (meals[i].getCalories() < min) {
                    min = meals[i].getCalories();
                }
                if (meals[i].getCalories() > max) {
                    max = meals[i].getCalories();
                }
                calories += meals[i].getCalories();

            }
        }
        mean = calories / total;
         Comparator<Meals> compareByVal = new Comparator<Meals>() {
            @Override
            public int compare(Meals o1, Meals o2) {
                return (""+o1.getCalories()).compareTo(""+o2.getCalories());
            }
        };
        display.sort(compareByVal);
        if (display.size() % 2 == 1) {
            median = display.get(display.size() / 2).getCalories();
        } else {
            median = (display.get(display.size() / 2).getCalories() + display.get(display.size() / 2 + 1).getCalories()) / 2;
        }
        return "Meal: " + meal1.toString() +", Total: " + total+", Mean: " + mean+", min: " + min+", max: " + max+", Median: " + median;

    }

    public void addElementWithStrings(String arg1, String arg2, String arg3) {
        MealType mealType;
        if (i < meals.length) {

            switch (arg1) {
                case "Breakfast":
                    mealType = MealType.BREAKFAST;
                    break;
                case "Lunch":
                    mealType = MealType.LUNCH;
                    break;
                case "Dinner":
                    mealType = MealType.DINNER;
                    break;
                case "Dessert":
                    mealType = MealType.DESSERT;
                    break;
                default:
                    mealType = MealType.DINNER;
                    System.out.println("Invalid Meal Type " + arg1 + ", defaulted to Dinner.");
            }

            if (arg3.matches("-?\\d+(\\.\\d+)?")) {
                calories = Integer.parseInt(arg3);
            } else {
                calories = 100;
                System.out.println("Invalid Calories " + arg3 + ", defaulted to 100.");
            }
            meals[i++] = new Meals(mealType, arg2, calories);
        }
        else {
            System.out.println("Items exceeded system size.  File has " + i + ", while the system can only handle " + meals.length + ".");
        }
    }

    public Meals[] getMeals() {
        return meals;
    }

    public void printAllMeals() {
        for (Meals item: meals) {
            if (item != null) {
                System.out.println(item);
            }

        }
    }

    public void printMealsByType(MealType mealType) {
        for (Meals item: meals) {
            if (item != null && item.getMealType() == mealType) {
                System.out.println(item);
            }

        }
    }

    public void printByNameSearch(String s) {
        for (Meals item: meals) {
            if (item != null && item.getItem().indexOf(s) >= 0) {
                System.out.println(item);
            }

        }
    }
}
